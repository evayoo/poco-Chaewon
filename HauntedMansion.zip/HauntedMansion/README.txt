You need to visit all the rooms to get a scholarship to get into PowerCoders. 
First, open the door of the haunted mansion. 
The door opens, and now you're in the Foyer. 

When you get into the room, always start from "description.txt"
